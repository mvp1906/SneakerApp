import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../models/product.dart';
import '../providers/cart_provider.dart';
import 'thank_you_screen.dart'; // Import the Thank You Screen

class CheckoutScreen extends StatefulWidget {
  @override
  _CheckoutScreenState createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final _formKey = GlobalKey<FormState>();
  String firstName = '';
  String lastName = '';
  String email = '';
  String houseNumber = '';
  String streetAddress = '';
  String city = '';
  String province = 'Ontario'; // Default value
  String zipCode = '';
  String phone = '';
  String paymentMethod = 'COD'; // Default payment method
  String cardNumber = '';
  String cardCVV = '';
  String cardExpiry = '';

  // List of Canadian provinces
  final List<String> provinces = [
    'Alberta',
    'British Columbia',
    'Manitoba',
    'New Brunswick',
    'Newfoundland and Labrador',
    'Nova Scotia',
    'Ontario',
    'Prince Edward Island',
    'Quebec',
    'Saskatchewan'
  ];

  // Function to validate expiry date
  bool _isExpiryDateValid(String expiry) {
    final currentDate = DateTime.now();
    final regex = RegExp(r'^(0[1-9]|1[0-2])\/\d{2}$');
    if (!regex.hasMatch(expiry)) {
      return false;
    }
    final parts = expiry.split('/');
    final month = int.parse(parts[0]);
    final year = int.parse('20${parts[1]}');
    final expiryDate = DateTime(year, month + 1); // Expiry is end of the month
    return expiryDate.isAfter(currentDate);
  }

  // Function to handle form submission
  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      final cartProvider = Provider.of<CartProvider>(context, listen: false);
      final cartItems = cartProvider.cartItems; // Get items in the cart
      final totalPrice = cartProvider.totalPrice(); // Get the total price from CartProvider

      // Navigate to the Thank You screen and pass necessary data
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ThankYouScreen(
            firstName: firstName,
            cartItems: cartItems,
            totalPrice: totalPrice,
          ),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please correct the errors in the form')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final cartProvider = Provider.of<CartProvider>(context);
    final cartItems = cartProvider.cartItems;

    double getTotalPrice() {
      return cartItems.fold(0, (sum, item) => sum + item.price * item.quantity);
    }

    double getTax() {
      return getTotalPrice() * 0.13; // 13% tax
    }

    double getTotalWithTax() {
      return getTotalPrice() + getTax();
    }

    return Scaffold(
      appBar: AppBar(title: Text('Checkout')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Right Section: Cart Summary
            Card(
              elevation: 4,
              margin: EdgeInsets.only(bottom: 16),
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Order Summary',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 10),
                    ...cartItems.map((product) {
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8.0),
                        child: Text(
                          '${product.name} x${product.quantity} - \$${(product.price * product.quantity).toStringAsFixed(2)}',
                        ),
                      );
                    }).toList(),
                    SizedBox(height: 10),
                    Divider(),
                    SizedBox(height: 10),
                    Text('Subtotal: \$${getTotalPrice().toStringAsFixed(2)}'),
                    Text('Tax (13%): \$${getTax().toStringAsFixed(2)}'),
                    SizedBox(height: 10),
                    Divider(),
                    SizedBox(height: 10),
                    Text('Total: \$${getTotalWithTax().toStringAsFixed(2)}',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ),

            // Left Section: Checkout Form
            Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // First Line: First Name, Last Name
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          decoration: InputDecoration(labelText: 'First Name'),
                          onChanged: (value) => setState(() => firstName = value),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your first name';
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(width: 10),
                      Expanded(
                        child: TextFormField(
                          decoration: InputDecoration(labelText: 'Last Name'),
                          onChanged: (value) => setState(() => lastName = value),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your last name';
                            }
                            return null;
                          },
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  TextFormField(
                    decoration: InputDecoration(labelText: 'Email'),
                    keyboardType: TextInputType.emailAddress,
                    onChanged: (value) => setState(() => email = value),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter your email';
                      } else if (!RegExp(r'^[^@]+@[^@]+\.[^@]+$').hasMatch(value)) {
                        return 'Please enter a valid email';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 10),

                  // Second Line: House Number, Street Address
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          decoration: InputDecoration(labelText: 'House/Apt. Number'),
                          onChanged: (value) => setState(() => houseNumber = value),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your house number';
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(width: 10),
                      Expanded(
                        child: TextFormField(
                          decoration: InputDecoration(labelText: 'Street Address'),
                          onChanged: (value) => setState(() => streetAddress = value),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your street address';
                            }
                            return null;
                          },
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),

                  // Third Line: City
                  TextFormField(
                    decoration: InputDecoration(labelText: 'City'),
                    onChanged: (value) => setState(() => city = value),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter your city';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 10),

                  // Fourth Line: Province Dropdown
                  DropdownButtonFormField<String>(
                    value: province,
                    onChanged: (value) => setState(() => province = value!),
                    decoration: InputDecoration(labelText: 'Province'),
                    items: provinces
                        .map((prov) => DropdownMenuItem<String>(
                      value: prov,
                      child: Text(prov, overflow: TextOverflow.ellipsis),
                    ))
                        .toList(),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please select a province';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 10),

                  // Fifth Line: Zip Code
                  TextFormField(
                    decoration: InputDecoration(labelText: 'Zip Code'),
                    onChanged: (value) => setState(() => zipCode = value),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter your zip code';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 10),

                  // Phone Number
                  TextFormField(
                    decoration: InputDecoration(labelText: 'Phone Number'),
                    keyboardType: TextInputType.phone,
                    onChanged: (value) => setState(() => phone = value),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter your phone number';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 10),

                  // Payment Method
                  Text(
                    'Payment Method',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: RadioListTile<String>(
                          title: Text('Cash on Delivery (COD)'),
                          value: 'COD',
                          groupValue: paymentMethod,
                          onChanged: (value) => setState(() => paymentMethod = value!),
                        ),
                      ),
                      Expanded(
                        child: RadioListTile<String>(
                          title: Text('Credit/Debit Card'),
                          value: 'Card',
                          groupValue: paymentMethod,
                          onChanged: (value) => setState(() => paymentMethod = value!),
                        ),
                      ),
                    ],
                  ),
                  if (paymentMethod == 'Card') ...[
                    SizedBox(height: 10),
                    TextFormField(
                      decoration: InputDecoration(labelText: 'Card Number'),
                      keyboardType: TextInputType.number,
                      onChanged: (value) => setState(() => cardNumber = value),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter your card number';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                    TextFormField(
                      decoration: InputDecoration(labelText: 'Card CVV'),
                      keyboardType: TextInputType.number,
                      obscureText: true, // Masks the CVV input
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly, // Allow only digits
                        LengthLimitingTextInputFormatter(3),   // Restrict to 3 characters
                      ],
                      onChanged: (value) => setState(() => cardCVV = value),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter your card CVV';
                        } else if (value.length != 3) {
                          return 'CVV must be 3 digits';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                    TextFormField(
                      decoration: InputDecoration(labelText: 'Card Expiry (MM/YY)'),
                      keyboardType: TextInputType.number,
                      onChanged: (value) => setState(() => cardExpiry = value),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter card expiry date';
                        } else if (!_isExpiryDateValid(value)) {
                          return 'Please enter a valid expiry date';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                  ],

                  // Submit Button
                  // Submit Button
                  SizedBox(
                    width: double.infinity, // Full-width button
                    child: ElevatedButton.icon(
                      icon: Icon(Icons.check),
                      label: Text('Submit Order'),
                      onPressed: _submitForm,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        foregroundColor: Colors.white, // Button text color
                        padding: EdgeInsets.symmetric(vertical: 16), // Increased padding for a larger button
                      ),
                    ),
                  ),

                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
