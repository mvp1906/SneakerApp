import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.orange[50],  // Light orange background color for warmth
      body: Padding(
        padding: const EdgeInsets.all(16.0),  // Add padding for spacing around edges
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,  // Center all elements
            children: [
              // Logo with shadow for a subtle 3D effect
              Container(
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 8.0,
                      offset: Offset(0, 4),
                    ),
                  ],
                ),
                child: Image.asset(
                  'assets/images/logo.png',
                  height: 200,  // Increased logo size for better visibility
                  width: 200,   // Make logo more prominent
                ),
              ),
              SizedBox(height: 30),
              // Welcome text with larger font and vibrant color
              Text(
                'Welcome to Our Store!',
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                  color: Colors.orange[800],  // Rich orange color for text
                ),
                textAlign: TextAlign.center,  // Center align text for neatness
              ),
              SizedBox(height: 30),
              // Shop Now button with gradient background and rounded corners
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(200, 50),  // Larger button size
                  backgroundColor: Colors.orange,  // Orange color for the button
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),  // Rounded corners
                  ),
                  shadowColor: Colors.orangeAccent,  // Button shadow color
                  elevation: 8,  // Button elevation for a floating effect
                ),
                onPressed: () {
                  Navigator.pushNamed(context, '/products');
                },
                child: Text(
                  'Shop Now',
                  style: TextStyle(
                    fontSize: 18,  // Slightly larger font size for clarity
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
