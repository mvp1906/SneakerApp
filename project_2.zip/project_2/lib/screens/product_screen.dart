import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/product.dart';
import '../providers/cart_provider.dart';
import '../widgets/product_card.dart';
import '../screens/cart_screen.dart';

class ProductScreen extends StatefulWidget {
  @override
  _ProductScreenState createState() => _ProductScreenState();
}

class _ProductScreenState extends State<ProductScreen> {
  List<Product> filteredProducts = products;
  String? selectedBrand;
  String? selectedSortOrder;

  // Apply filter based on brand and sorting
  void applyFilter() {
    setState(() {
      filteredProducts = products.where((product) {
        final matchesQuery = selectedBrand == null || product.brand == selectedBrand;
        return matchesQuery;
      }).toList();

      // Sorting logic
      if (selectedSortOrder != null) {
        switch (selectedSortOrder) {
          case 'High to Low':
            filteredProducts.sort((a, b) => b.price.compareTo(a.price));
            break;
          case 'Low to High':
            filteredProducts.sort((a, b) => a.price.compareTo(b.price));
            break;
          case 'Alphabetical':
            filteredProducts.sort((a, b) => a.name.compareTo(b.name));
            break;
        }
      }
    });
  }

  // Reset filters to show all products
  void resetFilters() {
    setState(() {
      selectedBrand = null;
      selectedSortOrder = null;
      filteredProducts = products; // Reset product list
    });
  }

  // Show filter dialog for brand and sorting
  void openFilterDialog() {
    String? tempSelectedBrand = selectedBrand;
    String? tempSelectedSortOrder = selectedSortOrder;

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: Text('Filter Products', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Brand Filter
                  DropdownButton<String>(
                    hint: Text('Select Brand'),
                    value: tempSelectedBrand,
                    onChanged: (String? newValue) {
                      setDialogState(() {
                        tempSelectedBrand = newValue; // Update temporary selection
                      });
                    },
                    items: ['New Balance', 'Nike', 'Jordan', 'Converse']
                        .map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value, style: TextStyle(fontSize: 16)),
                      );
                    }).toList(),
                    isExpanded: true,  // Make the dropdown list expand to fill the width
                  ),
                  SizedBox(height: 20),

                  // Sort Filter
                  DropdownButton<String>(
                    hint: Text('Sort By'),
                    value: tempSelectedSortOrder,
                    onChanged: (String? newValue) {
                      setDialogState(() {
                        tempSelectedSortOrder = newValue; // Update temporary selection
                      });
                    },
                    items: ['High to Low', 'Low to High', 'Alphabetical']
                        .map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value, style: TextStyle(fontSize: 16)),
                      );
                    }).toList(),
                    isExpanded: true,  // Make the dropdown list expand to fill the width
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text('Cancel', style: TextStyle(color: Colors.red)),
                ),
                TextButton(
                  onPressed: () {
                    resetFilters(); // Reset filters
                    Navigator.pop(context);
                  },
                  child: Text('Reset', style: TextStyle(color: Colors.grey)),
                ),
                TextButton(
                  onPressed: () {
                    setState(() {
                      selectedBrand = tempSelectedBrand; // Save final selection
                      selectedSortOrder = tempSelectedSortOrder;
                    });
                    applyFilter(); // Apply filters
                    Navigator.pop(context);
                  },
                  child: Text('Apply', style: TextStyle(color: Colors.blue)),
                ),
              ],
            );
          },
        );
      },
    );
  }

  // Add product to cart or update quantity if already in cart
  void addToCart(Product product) {
    // Use the CartProvider to add the product to the cart
    Provider.of<CartProvider>(context, listen: false).addToCart(product);

    // Show a snackbar indicating that the product was added to the cart
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${product.name} added to cart!'),
      ),
    );
  }

  // Navigate to Cart Screen
  void openCartScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CartScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Products'),
        backgroundColor: Colors.deepOrange,  // Vibrant app bar color
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'Search products...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0), // Rounded corners
                      ),
                      prefixIcon: Icon(Icons.search),
                      filled: true,
                      fillColor: Colors.grey[200],  // Light background for the search box
                    ),
                    onChanged: (query) {
                      searchProducts(query);
                    },
                  ),
                ),
                SizedBox(width: 8.0),
                IconButton(
                  icon: Icon(Icons.filter_list),
                  onPressed: openFilterDialog, // Open filter dialog
                  color: Colors.deepOrange,
                ),
                IconButton(
                  icon: Icon(Icons.shopping_cart),
                  onPressed: openCartScreen, // Open cart screen
                  color: Colors.deepOrange,
                ),
              ],
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(8.0),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12.0,
                mainAxisSpacing: 12.0,
                childAspectRatio: 0.75,
              ),
              itemCount: filteredProducts.length,
              itemBuilder: (context, index) {
                return ProductCard(
                  product: filteredProducts[index],
                  onAddToCart: () => addToCart(filteredProducts[index]), // Pass addToCart callback
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // Search products by name
  void searchProducts(String query) {
    final results = products
        .where((product) =>
    product.name.toLowerCase().contains(query.toLowerCase()) ||
        product.brand.toLowerCase().contains(query.toLowerCase()))
        .toList();
    setState(() {
      filteredProducts = results;
    });
  }
}
