import 'package:flutter/material.dart';
import 'package:provider/provider.dart'; // Ensure to import provider package
import '../models/product.dart'; // Assuming Product model is imported
import '../providers/cart_provider.dart'; // Import your CartProvider
import '../screens/product_screen.dart'; // Assuming ProductScreen is where you want to navigate to

class ThankYouScreen extends StatelessWidget {
  final String firstName;
  final List<Product> cartItems;
  final double totalPrice;

  ThankYouScreen({
    required this.firstName,
    required this.cartItems,
    required this.totalPrice,
  });

  double getSubtotal() {
    return cartItems.fold(0.0, (sum, product) {
      return sum + (product.price * product.quantity);
    });
  }

  double getTax() {
    return getSubtotal() * 0.13; // 13% tax
  }

  double getTotal() {
    return getSubtotal() + getTax();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Thank You')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Greeting
            Text(
              'Thank You, $firstName!',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),

            // Order Summary Heading
            Text(
              'Your Order Summary:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),

            // Bill Details (Products List, Subtotal, Tax, Total)
            Expanded(
              child: ListView(
                children: [
                  // Products List
                  ...cartItems.map(
                        (product) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              product.name,
                              style: TextStyle(fontSize: 16),
                            ),
                            Text(
                              'x${product.quantity}',
                              style: TextStyle(fontSize: 16),
                            ),
                            Text(
                              '\$${(product.price * product.quantity).toStringAsFixed(2)}',
                              style: TextStyle(fontSize: 16),
                            ),
                          ],
                        ),
                      );
                    },
                  ).toList(),

                  SizedBox(height: 20),

                  // Divider line between products and totals
                  Divider(),

                  SizedBox(height: 10),

                  // Subtotal, Tax, Total Price
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Subtotal:',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        '\$${getSubtotal().toStringAsFixed(2)}',
                        style: TextStyle(fontSize: 16),
                      ),
                    ],
                  ),
                  SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Tax (13%):',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        '\$${getTax().toStringAsFixed(2)}',
                        style: TextStyle(fontSize: 16),
                      ),
                    ],
                  ),
                  SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Total:',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        '\$${getTotal().toStringAsFixed(2)}',
                        style: TextStyle(fontSize: 16),
                      ),
                    ],
                  ),

                  SizedBox(height: 20),
                  Divider(),
                  SizedBox(height: 20),

                  // Thank You Note
                  Text(
                    'Thank you for shopping with us!',
                    style: TextStyle(fontSize: 16, fontStyle: FontStyle.italic),
                  ),
                ],
              ),
            ),

            // Back to Shopping Button
            Center(
              child: ElevatedButton(
                onPressed: () {
                  // Clear the cart and navigate back to ProductScreen
                  Provider.of<CartProvider>(context, listen: false).clearCart();
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => ProductScreen()),
                  );
                },
                child: Text('Back to Shopping'),
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
