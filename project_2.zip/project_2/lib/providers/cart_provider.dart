import 'package:flutter/material.dart';
import '../models/product.dart';

class CartProvider with ChangeNotifier {
  List<Product> _cartItems = [];

  List<Product> get cartItems => _cartItems;

  void addToCart(Product product) {
    // Check if the product is already in the cart
    final existingProductIndex = _cartItems.indexWhere((item) => item.id == product.id);

    if (existingProductIndex != -1) {
      // If it exists, increase its quantity
      _cartItems[existingProductIndex].quantity++;
    } else {
      // Add the product if it doesn't exist, setting quantity to 1
      _cartItems.add(Product(
        id: product.id,
        name: product.name,
        price: product.price,
        description: product.description,
        image: product.image,
        quantity: 1, brand: '', // Initialize quantity to 1
      ));
    }
    notifyListeners(); // Notify listeners to update the UI
  }

  void updateProductQuantity(Product product, int quantityChange) {
    final existingProductIndex = _cartItems.indexWhere((item) => item.id == product.id);

    if (existingProductIndex != -1) {
      _cartItems[existingProductIndex].quantity += quantityChange;

      // Prevent the quantity from going below 1
      if (_cartItems[existingProductIndex].quantity < 1) {
        _cartItems[existingProductIndex].quantity = 1;
      }
      notifyListeners();
    }
  }

  void removeFromCart(Product product) {
    _cartItems.remove(product);
    notifyListeners();
  }

  void clearCart() {
    _cartItems.clear();
    notifyListeners();
  }

  double totalPrice() {
    double total = 0;
    for (var item in _cartItems) {
      total += item.price * item.quantity;
    }
    return total;
  }
}
