import 'package:flutter/material.dart';
import 'package:project_2/screens/cart_screen.dart';
import 'package:provider/provider.dart'; // Import Provider
import 'screens/home_screen.dart';
import 'screens/product_screen.dart';
import 'screens/detail_screen.dart';
import 'screens/checkout_screen.dart';
import 'models/product.dart';
import 'providers/cart_provider.dart'; // Import the CartProvider

void main() => runApp(
  ChangeNotifierProvider(
    create: (context) => CartProvider(), // Provide CartProvider to the app
    child: MyApp(),
  ),
);

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'eCommerce App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        hintColor: Colors.orange,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => HomeScreen(),
        '/products': (context) => ProductScreen(),
        '/checkout': (context) => CheckoutScreen(),
        '/cart': (context) => CartScreen(),
      },
      onGenerateRoute: (settings) {
        if (settings.name == '/details') {
          final product = settings.arguments as Product;
          return MaterialPageRoute(
            builder: (context) => DetailScreen(product),
          );
        }
        return null;
      },
    );
  }
}
