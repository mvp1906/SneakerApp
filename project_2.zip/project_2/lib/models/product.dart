class Product {
  final String id;
  final String name;
  final String brand;
  final double price;
  final String description;
  final String image;
  int quantity;

  Product({
    required this.id,
    required this.name,
    required this.brand,
    required this.price,
    required this.description,
    required this.image,
    this.quantity = 1,
  });
}

final List<Product> products = [
  Product(
    id: '1',
    name: 'CAYL x New Balance 1906R',
    brand: 'New Balance',
    price: 224.99,
    description: 'A new collaborative design from CAYL and New Balance draws on the 1906R’s roots as a high-end performance runner, by way of an off-road detour.',
    image:'assets/images/shoe1.png',
  ),
  Product(
    id: '2',
    name: 'Fresh Foam X 1080v14',
    brand: 'New Balance',
    price: 209.99,
    description: 'If we only made one running shoe, it would be the Fresh Foam X 1080.',
    image:'assets/images/shoe2.png',
  ),
  Product(
    id: '3',
    name: 'FuelCell Rebel v4',
    brand: 'New Balance',
    price: 179.99,
    description: 'Rebel by name, rebel by nature, the FuelCell Rebel v4 will change the way you look at an everyday trainer.',
    image:'assets/images/shoe3.png',
  ),
  Product(
    id: '4',
    name: 'Air Force 1 07',
    brand: 'Nike',
    price: 120.99,
    description: 'Score major style points with this legendary hoops classic. ',
    image:'assets/images/shoe4.png',
  ),
  Product(
    id: '5',
    name: 'Air Max Plus',
    brand: 'Nike',
    price: 235,
    description: 'Let your attitude have the edge in your Nike Air Max Plus, a Tuned Air experience that offers premium stability and unbelievable cushioning.',
    image:'assets/images/shoe5.png',
  ),
  Product(
    id: '6',
    name: 'Dunk Low',
    brand: 'Nike',
    price: 165,
    description: 'Created for the hardwood but taken to the streets, this 80s basketball icon returns with classic details and throwback hoops flair.',
    image:'assets/images/shoe6.png',
  ),
  Product(
    id: '7',
    name: 'Spizike Low',
    brand: 'Jordan',
    price: 210,
    description: 'The Spizike takes elements of five classic Jordans, combines them and gives you one iconic sneaker.',
    image:'assets/images/shoe7.png',
  ),
  Product(
    id: '8',
    name: 'Air Jordan 1 Low',
    brand: 'Jordan',
    price: 120.99,
    description: 'Inspired by the original that debuted in 1985, the Air Jordan 1 Low offers a clean, classic look thats familiar yet always fresh.',
    image:'assets/images/shoe8.png',
  ),
  Product(
    id: '9',
    name: 'Jumpman MVP',
    brand: 'Jordan',
    price: 150.99,
    description: 'We did not invent the remix—but considering the material we get to sample, this ones a no-brainer.',
    image:'assets/images/shoe9.png',
  ),
  Product(
    id: '10',
    name: 'Chuck 70 Low Top',
    brand: 'Converse',
    price: 70.99,
    description: 'The Converse All Star Chuck ’70 is our re-crafted sneaker that uses modern details to celebrate the original Chuck Taylor All Star from the 1970s.',
    image:'assets/images/shoe10.png',
  ),
];
